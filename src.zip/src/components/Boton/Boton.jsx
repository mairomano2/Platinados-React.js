import "./boton.css"

export const Boton = ({texto}) => {
  return (
    <button className="botonPersonalizado parrafos">{texto}</button>
  )
}