import { useState, createContext, useContext } from "react"

export const MisionesContext = createContext()

export const UseMisionesContext = () => useContext(MisionesContext)

export const MisionesContextProvider = ({children}) => {

  const [misionesCompletadas, setMisionesCompletadas] = useState([{ id: 1 }, { id: 2 }, { id: 3 }])

  const agregarMision = (mision, cantidad) => {

    const completada = (item) => {
      return misionesCompletadas.some((misionID => misionID.id === item.id))
    }

    if (completada) {
      let nuevalista = misionesCompletadas
      misionesCompletadas.forEach((misionID) => {
        if (misionID.id === mision.id) {
          misionID.cantidad += cantidad
        }
      })
      setMisionesCompletadas(nuevalista)
    } else {
      setMisionesCompletadas(...misionesCompletadas, { ...mision, cantidad })
    }
  }

  const borrarMision = id => {
    setMisionesCompletadas(misionesCompletadas.filter(mision => mision.id !== id))
    console.log(misionesCompletadas)
  }

  const limpiarCarrito = () => {
    setMisionesCompletadas([])
    console.log(misionesCompletadas)
  }

  const value = { misionesCompletadas, agregarMision, borrarMision, limpiarCarrito }

  return (
    <MisionesContext.Provider value={value}>
      <button onClick={agregarMision({ id: 1, cantidad: 2 })}>Agregar item</button>
      <button onClick={borrarMision(1)}>borrar item</button>
      <button onClick={limpiarCarrito}>limpiar carrito</button>
    </MisionesContext.Provider>
  )
}