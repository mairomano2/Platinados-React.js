import { useState, useContext, createContext} from "react"

export const MisionesContext = createContext({ misionesCompletadas : [] })

let ultimoID = 0;

export const MisionesContextProvider = ({children}) => {

  const m = useContext(MisionesContext);
  const [misionesCompletadas, setMisionesCompletadas] = useState(m.misionesCompletadas)

  const agregarMision = (nuevaMision) => {

    setMisionesCompletadas((misionesAnteriores) => {
        return [...misionesAnteriores, ...nuevaMision ]
    })
    ultimoID++;
  }

  const value = { misionesCompletadas, agregarMision }

  return (
    <MisionesContext.Provider value={value}>
      {children}
    </MisionesContext.Provider>
  )
}