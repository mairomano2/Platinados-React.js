import {useState, useEffect} from "react"
import {ItemList} from "./ItemList"
import {promesa} from "./ApiSimulada"

export const Items = () => {

  const [mision, setMisiones] = useState([])
  const [cargando, setCargando] = useState(true)

  useEffect( () => {
    promesa.then(res => {
      setMisiones(res)
    })
    promesa.catch(error => console.log(error))
    promesa.finally( () => {setCargando(false)} )
  },[])

  console.log(mision)

  return (
    cargando ? <h1>Cargando...</h1> : <ItemList misiones={mision}/>
  )
}

export default Items


