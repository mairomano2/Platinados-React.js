import { MisionesContextProvider } from "../Context/MisionesContext"

export function MisionesCompletadas (){

  return(
  <div>
    <h1>Misiones completadas</h1>
    <MisionesContextProvider />
  </div>
  )
}

